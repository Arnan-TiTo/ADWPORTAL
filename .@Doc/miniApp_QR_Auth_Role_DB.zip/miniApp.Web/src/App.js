
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Login from './pages/Login';
import Register from './pages/Register';
import Homepage from './pages/Homepage';
import StockAdjust from './pages/StockAdjust';
import StockIn from './pages/StockIn';
import StockCount from './pages/StockCount';
import FindLocation from './pages/FindLocation';
import ProtectedRoute from './routes/ProtectedRoute';

export default function App() {
    return (
        <Router>
            <nav className="p-4 bg-green-600 text-white flex gap-4">
                <Link to="/">Home</Link>
                <Link to="/login">Login</Link>
                <Link to="/register">Register</Link>
                <Link to="/find-location">Find</Link>
                <Link to="/stock-adjust">Adjust</Link>
                <Link to="/stock-in">In</Link>
                <Link to="/stock-count">Count</Link>
            </nav>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/" element={
                    <ProtectedRoute><Homepage /></ProtectedRoute>
                } />
                <Route path="/find-location" element={
                    <ProtectedRoute><FindLocation /></ProtectedRoute>
                } />
                <Route path="/stock-adjust" element={
                    <ProtectedRoute><StockAdjust /></ProtectedRoute>
                } />
                <Route path="/stock-in" element={
                    <ProtectedRoute><StockIn /></ProtectedRoute>
                } />
                <Route path="/stock-count" element={
                    <ProtectedRoute><StockCount /></ProtectedRoute>
                } />
            </Routes>
        </Router>
    );
}
