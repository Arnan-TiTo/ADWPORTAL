
export const loginWithQr = async () => {
    const res = await fetch('http://localhost:5000/api/qrlogin/generate?username=testuser');
    const { qrToken } = await res.json();
    return qrToken;
};

export const confirmQrToken = async (token) => {
    const res = await fetch('http://localhost:5000/api/qrlogin/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(token)
    });
    const data = await res.json();
    if (data.token) {
        localStorage.setItem('jwt', data.token);
        return true;
    }
    return false;
};

export const getToken = () => localStorage.getItem('jwt');
export const logout = () => localStorage.removeItem('jwt');
