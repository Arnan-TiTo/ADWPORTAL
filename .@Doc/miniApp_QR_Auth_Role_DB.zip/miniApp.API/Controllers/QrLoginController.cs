
using Microsoft.AspNetCore.Mvc;
using miniApp.API.Auth;

namespace miniApp.API.Controllers {
    [ApiController]
    [Route("api/[controller]")]
    public class QrLoginController : ControllerBase {
        private static Dictionary<string, string> pendingTokens = new();

        [HttpGet("generate")]
        public IActionResult GenerateQrToken(string username) {
            string token = Guid.NewGuid().ToString();
            pendingTokens[token] = username;
            return Ok(new { qrToken = token });
        }

        [HttpPost("scan")]
        public IActionResult ScanQrToken([FromBody] string token) {
            if (pendingTokens.ContainsKey(token)) {
                string username = pendingTokens[token];
                var jwt = new JwtService("supersecretkey123").GenerateToken(username);
                pendingTokens.Remove(token);
                return Ok(new { token = jwt });
            }
            return Unauthorized();
        }
    }
}
