
# EF Core Migrations (run in terminal at miniApp.API folder)
dotnet ef migrations add InitialCreate
dotnet ef database update
